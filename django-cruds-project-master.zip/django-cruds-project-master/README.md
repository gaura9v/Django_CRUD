# Django CRUDS Project
A simple django CRUDS project that will help to learn the basic operations on database.

## Setup this Project

### Clone this project
```
git clone https://github.com/Aashishkumar123/django-cruds-project
```

### Install following dependencies
```
pip install django
```

### Run project
```
python manage.py runserver
```
